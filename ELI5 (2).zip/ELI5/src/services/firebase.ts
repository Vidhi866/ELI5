
import { initializeApp } from 'firebase/app';
import { 
  getAuth, 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  User
} from 'firebase/auth';

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyC71DuVDxaflKNqWSOVaJP5NMVW3E5_xMw",
  authDomain: "notes-summarizer-a3d2e.firebaseapp.com",
  projectId: "notes-summarizer-a3d2e",
  storageBucket: "notes-summarizer-a3d2e.firebasestorage.app",
  messagingSenderId: "619265810363",
  appId: "1:619265810363:web:ba9e784811ce8ef87e6e9e",
  measurementId: "G-TC6TZHN74C"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);

// Auth functions
export const signUp = (email: string, password: string) => {
  return createUserWithEmailAndPassword(auth, email, password);
};

export const signIn = (email: string, password: string) => {
  return signInWithEmailAndPassword(auth, email, password);
};

export const signOut = () => {
  return firebaseSignOut(auth);
};

export const getCurrentUser = (): Promise<User | null> => {
  return new Promise((resolve) => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      unsubscribe();
      resolve(user);
    });
  });
};
