
import { GoogleGenerativeAI } from "@google/generative-ai";

// The API key
const API_KEY = "AIzaSyAG_rNuQm4OQsrFrGatX9Ny8rdE3B-AZtA";

// Initialize the Gemini API
const genAI = new GoogleGenerativeAI(API_KEY);

/**
 * Gets a kid-friendly explanation for a complex topic using the Gemini API
 * @param topic - The complex topic to explain
 * @returns A Promise with the explanation text
 */
export async function getExplanation(topic: string): Promise<string> {
  try {
    // Get the generative model
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
    
    // Create the prompt for kid-friendly explanation
    const prompt = `Explain ${topic} like I'm 5 years old. Use simple words and fun examples a kid would love.`;
    
    // Generate content from the model
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    
    return text;
  } catch (error) {
    console.error("Error getting explanation:", error);
    throw new Error("Failed to get explanation. Please try again.");
  }
}
