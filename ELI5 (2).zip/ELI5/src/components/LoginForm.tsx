
import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { Mail, Lock, UserPlus, LogIn } from 'lucide-react';

const LoginForm = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { login, register } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      if (isLogin) {
        await login(email, password);
      } else {
        await register(email, password);
      }
    } catch (error) {
      console.error("Auth error:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="eli5-card max-w-md w-full mx-auto">
      <div className="flex flex-col items-center mb-6">
        <div className="w-16 h-16 rounded-full bg-eli5-purple/20 flex items-center justify-center mb-4">
          {isLogin ? 
            <LogIn className="w-8 h-8 text-eli5-purple" /> : 
            <UserPlus className="w-8 h-8 text-eli5-purple" />
          }
        </div>
        <h1 className="text-2xl font-bold">
          {isLogin ? 'Welcome Back!' : 'Create Account'}
        </h1>
        <p className="text-gray-500 mt-1">
          {isLogin ? 'Login to continue learning' : 'Sign up to start learning'}
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <div className="flex items-center">
            <Mail className="w-5 h-5 mr-2 text-gray-500" />
            <label htmlFor="email" className="text-sm font-medium">Email</label>
          </div>
          <Input
            id="email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="eli5-input"
            placeholder="your@email.com"
            required
          />
        </div>

        <div className="space-y-2">
          <div className="flex items-center">
            <Lock className="w-5 h-5 mr-2 text-gray-500" />
            <label htmlFor="password" className="text-sm font-medium">Password</label>
          </div>
          <Input
            id="password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="eli5-input"
            placeholder="••••••••"
            required
            minLength={6}
          />
        </div>

        <Button 
          type="submit" 
          className="eli5-button w-full py-6"
          disabled={isSubmitting}
        >
          {isSubmitting ? 
            'Loading...' : 
            (isLogin ? 'Log In' : 'Sign Up')
          }
        </Button>
      </form>

      <div className="text-center mt-6">
        <button
          type="button"
          onClick={() => setIsLogin(!isLogin)}
          className="text-eli5-purple hover:underline font-medium"
        >
          {isLogin ? "Don't have an account? Sign up" : "Already have an account? Log in"}
        </button>
      </div>
    </div>
  );
};

export default LoginForm;
