
import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { getExplanation } from '@/services/geminiService';
import { useToast } from '@/hooks/use-toast';
import { Brain, Lightbulb, Loader2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

const ExplainForm = () => {
  const [topic, setTopic] = useState('');
  const [explanation, setExplanation] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const { logout } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) {
      toast({
        title: "Topic Required",
        description: "Please enter a topic to explain",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    setExplanation('');

    try {
      const result = await getExplanation(topic);
      setExplanation(result);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to get explanation",
        variant: "destructive",
      });
      console.error("Explanation error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      <div className="flex justify-end mb-4">
        <Button 
          variant="outline" 
          onClick={logout}
          className="text-sm"
        >
          Logout
        </Button>
      </div>

      <div className="eli5-card">
        <div className="flex items-center justify-center mb-8 gap-3">
          <Brain className="w-10 h-10 text-eli5-purple animate-bounce-slow" />
          <h1 className="text-3xl font-bold text-center">
            Explain Like I'm 5
          </h1>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label htmlFor="topic" className="text-lg font-medium">
              Enter a complex topic:
            </label>
            <Input
              id="topic"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g., Quantum physics, climate change, how the internet works..."
              className="eli5-input py-6 text-lg"
              disabled={isLoading}
            />
          </div>

          <Button 
            type="submit" 
            className="eli5-button py-6 w-full"
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                Getting your explanation...
              </>
            ) : (
              <>
                <Lightbulb className="mr-2 h-5 w-5" />
                Explain It!
              </>
            )}
          </Button>
        </form>

        {explanation && (
          <div className="mt-8">
            <h2 className="text-xl font-semibold flex items-center mb-4">
              <Lightbulb className="w-6 h-6 mr-2 text-eli5-yellow" />
              Simple Explanation:
            </h2>
            <div className="explanation-box">
              <p className="whitespace-pre-line text-lg">{explanation}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ExplainForm;
