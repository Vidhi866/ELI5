
import React from 'react';
import LoginForm from '@/components/LoginForm';
import ExplainForm from '@/components/ExplainForm';
import { useAuth } from '@/contexts/AuthContext';
import { Loader2 } from 'lucide-react';

const Index = () => {
  const { currentUser, loading } = useAuth();

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <Loader2 className="w-10 h-10 text-eli5-purple animate-spin mb-4" />
        <p className="text-lg text-gray-600">Loading...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-eli5-purple/5 py-12 px-4">
      <div className="container max-w-5xl mx-auto">
        {currentUser ? <ExplainForm /> : <LoginForm />}
        
        <footer className="mt-16 text-center text-gray-500 text-sm">
          <p>© 2025 Explain Like I'm 5 (ELI5) - Made for curious minds</p>
        </footer>
      </div>
    </div>
  );
};

export default Index;
